var that = this;
function __skpm_run (key, context) {
  that.context = context;

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 2);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ }),
/* 1 */
/***/ (function(module, exports) {

module.exports = require("sketch/settings");

/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

Object.defineProperty(exports, "__esModule", {
    value: true
});

exports['default'] = function (context) {
    var document = _dom2['default'].getSelectedDocument();
    var selectedLayers = document.selectedLayers;
    if (selectedLayers.isEmpty) {
        _ui2['default'].message('No selected things');
        return;
    }
    selectedLayers.forEach(function (layer) {
        var parentArtb = (0, _getParentArtb2['default'])(layer);
        if (!parentArtb) {
            _ui2['default'].message('It isn\'t in an artboard.');
            return;
        }
        if (!_ids2['default'].isExist(parentArtb.id)) {
            var blurAmount = _blurLayer2['default'].getBlurAmount();
            _blurLayer2['default'].createFromArtb(parentArtb, blurAmount);
            _ids2['default'].addNewId(parentArtb.id);
            _ui2['default'].message('Blured');
        } else {
            _blurLayer2['default'].removeFromArtb(parentArtb);
            _ids2['default'].removeId(parentArtb.id);
            _ui2['default'].message('Unblured');
        }
    });
};

var _ui = __webpack_require__(3);

var _ui2 = _interopRequireDefault(_ui);

var _dom = __webpack_require__(0);

var _dom2 = _interopRequireDefault(_dom);

var _blurLayer = __webpack_require__(4);

var _blurLayer2 = _interopRequireDefault(_blurLayer);

var _getParentArtb = __webpack_require__(5);

var _getParentArtb2 = _interopRequireDefault(_getParentArtb);

var _ids = __webpack_require__(6);

var _ids2 = _interopRequireDefault(_ids);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

/***/ }),
/* 3 */
/***/ (function(module, exports) {

module.exports = require("sketch/ui");

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _dom = __webpack_require__(0);

var _dom2 = _interopRequireDefault(_dom);

var _settings = __webpack_require__(1);

var _settings2 = _interopRequireDefault(_settings);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var KEY = 'net.duanjun.blurartb.layerid';
var NAME = '__BLUR_LAYER__';
exports['default'] = {
    getBlurAmount: function () {
        function getBlurAmount() {
            var value = _settings2['default'].documentSettingForKey(_dom2['default'].getSelectedDocument(), 'net.duanjun.blurartb.bluramount');
            if (!value) {
                value = 4; //default blur amount
                this.setBlurAmount(value);
            }
            return value;
        }

        return getBlurAmount;
    }(),
    setBlurAmount: function () {
        function setBlurAmount(value) {
            _settings2['default'].setDocumentSettingForKey(_dom2['default'].getSelectedDocument(), 'net.duanjun.blurartb.bluramount', value);
        }

        return setBlurAmount;
    }(),
    createLayer: function () {
        function createLayer(parent, amount) {
            //Note: There's no resizing api!
            return new _dom.Shape({
                name: NAME,
                parent: parent,
                locked: true,
                frame: new _dom.Rectangle(0, 0, parent.frame.width, parent.frame.height),
                style: {
                    borders: [{
                        enabled: false
                    }],
                    fills: [{
                        color: '#ffffff00',
                        fillType: _dom.Style.FillType.Color
                    }],
                    blur: {
                        radius: amount,
                        blurType: _dom.Style.BlurType.Background,
                        enabled: true
                    }
                }
            });
        }

        return createLayer;
    }(),
    removeLayer: function () {
        function removeLayer(layer) {
            layer.remove();
        }

        return removeLayer;
    }(),
    createFromArtb: function () {
        function createFromArtb(targetArtb, amount) {
            var newShape = this.createLayer(targetArtb, amount);
            _settings2['default'].setLayerSettingForKey(targetArtb, KEY, newShape.id);
            return newShape.moveToFront();
        }

        return createFromArtb;
    }(),
    removeFromArtb: function () {
        function removeFromArtb(targetArtb) {
            var document = _dom2['default'].getSelectedDocument();
            var layerId = _settings2['default'].layerSettingForKey(targetArtb, KEY);
            var layer = document.getLayerWithID(layerId);
            if (layer) {
                this.removeLayer(layer);
            }
        }

        return removeFromArtb;
    }(),
    changeAmount: function () {
        function changeAmount(targetArtb, amount) {
            var document = _dom2['default'].getSelectedDocument();
            var layerId = _settings2['default'].layerSettingForKey(targetArtb, KEY);
            var layer = document.getLayerWithID(layerId);
            layer.style.blur.radius = amount;
        }

        return changeAmount;
    }()
};

/***/ }),
/* 5 */
/***/ (function(module, exports) {

Object.defineProperty(exports, "__esModule", {
    value: true
});

exports['default'] = function (child) {
    if (child.type == 'Artboard') {
        return child; //return artboard itself
    } else {
        return checker(child);
    }
    function checker(target) {
        if (target.parent.type == 'Artboard') {
            return target.parent;
        } else if (target.parent.type == 'Page') {
            return false;
        } else {
            return checker(target.parent);
        }
    }
};

/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _dom = __webpack_require__(0);

var _dom2 = _interopRequireDefault(_dom);

var _settings = __webpack_require__(1);

var _settings2 = _interopRequireDefault(_settings);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

// 设置document setting用来记录blur layer的ID
var document = _dom2['default'].getSelectedDocument();
var KEY = 'net.duanjun.blurartb.ids';
exports['default'] = {
    getIds: function () {
        function getIds() {
            var ids = _settings2['default'].documentSettingForKey(document, KEY);
            if (!ids) {
                ids = [];
                this.setIds(ids);
            }
            return ids;
        }

        return getIds;
    }(),
    setIds: function () {
        function setIds(data) {
            _settings2['default'].setDocumentSettingForKey(document, KEY, data);
        }

        return setIds;
    }(),
    addNewId: function () {
        function addNewId(newId) {
            if (this.isExist(newId)) return;
            var ids = this.getIds();
            ids.push(newId);
            this.setIds(ids);
        }

        return addNewId;
    }(),
    removeId: function () {
        function removeId(targetId) {
            var self = this;
            if (!self.isExist(targetId)) return;
            var ids = self.getIds();
            ids.splice(ids.indexOf(targetId), 1);
            self.setIds(ids);
        }

        return removeId;
    }(),
    isExist: function () {
        function isExist(targetId) {
            var ids = this.getIds();
            if (ids.indexOf(targetId) !== -1) return true;
            return false;
        }

        return isExist;
    }(),
    purify: function () {
        function purify() {
            var self = this;
            var ids = self.getIds();
            ids = Array.from(new Set(ids));
            var temp_array = [];
            ids.forEach(function (item) {
                if (document.getLayerWithID(item)) temp_array.push(item);
            });
            self.setIds(temp_array);
        }

        return purify;
    }()
};

/***/ })
/******/ ]);
  if (key === 'default' && typeof exports === 'function') {
    exports(context);
  } else {
    exports[key](context);
  }
}
that['onRun'] = __skpm_run.bind(this, 'default')
